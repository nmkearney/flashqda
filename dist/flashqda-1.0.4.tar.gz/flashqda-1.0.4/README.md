# FlashQDA

This is a package for using Large Language Models for qualitative data analysis.

To install:

1. Open Terminal.
2. Type: python3 -m pip install flashqda

A user guide is in development. In the meantime, a QuickStart guide is available in the Docs folder.

For more information, visit https://github.com/nmkearney/flashqda.